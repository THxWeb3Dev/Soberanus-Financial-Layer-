# SOBERANUS | The Financial Layer

![Project Status](https://img.shields.io/badge/Status-Active-gold)

![Privacy](https://img.shields.io/badge/Privacy-100%25-green)

![License](https://img.shields.io/badge/License-Proprietary-darkred)

> "Transforme dados em controle. Transforme controle em soberania."

## 🏛️ Manifesto

O SOBERANUS é um sistema de gestão financeira descentralizada (DeFi Management) criado para quem exige ordem, clareza e autonomia no universo cripto. 

Diferente de plataformas tradicionais que monitoram seus dados, o SOBERANUS opera sob a filosofia Local-First:

- Zero Vigilância: Nenhum dado sai do seu dispositivo.

- Zero Intermediários: Sem banco de dados na nuvem.

- Soberania Absoluta: Suas chaves, seus registros, suas regras.

## ⚡ Funcionalidades

### 🛡️ Soberania Digital

Controle absoluto sobre registros de compras, vendas e taxas. O poder volta para o titular.

### 📊 Gestão Inteligente

- Registro preciso de operações (BRL/DePIX/Crypto).

- Widgets de PnL (Lucro e Prejuízo) em tempo real.

- Cálculo automático de preço médio e taxas.

### 🔐 Privacidade & Segurança

- Armazenamento 100% via LocalStorage criptografado no navegador.

- Sem logs de IP.

- Sem rastreadores de terceiros.

### ⚖️ Relatório Fiscal (IR)

Geração automática de PDF auxiliar para Declaração de Imposto de Renda, consolidando:

- Total Comprado vs Vendido.

- Total de Taxas operacionais (Prejuízo abatível).

- Resultado de caixa anual.

### 💸 Gateway Descentralizado

Integração via API para geração de QR Codes PIX (Copia e Cola) para doações e liquidação, sem expor dados sensíveis na interface.

## 🛠️ Stack Tecnológico

O projeto foi construído utilizando tecnologias leves e universais para garantir portabilidade (Web, Android, iOS):

- Core: HTML5, JavaScript (ES6+).

- Estilização: Tailwind CSS (via CDN para agilidade).

- Gráficos: Chart.js.

- Relatórios: jsPDF & AutoTable.

- QR Code: QRCode.js.

- Alertas: SweetAlert2.

## 🚀 Como Rodar

1. Clone este repositório:

   `bash

   git clone [https://github.com/seu-usuario/soberanus.git](https://github.com/seu-usuario/soberanus.git)

2. Abra o arquivo index.html em qualquer navegador moderno.

3. Não é necessário instalação de servidores (Node/PHP/Python). O sistema é Client-Side.

## 🤝 Contribuição Soberana

O SOBERANUS é mantido de forma independente.

- Se este sistema gera valor para você, contribuições voluntárias ajudam a sustentar sua continuidade.

Endereços Oficiais:

- Bitcoin | On-Chain: bc1qvsu6n806jg8zswkvpyqxe9dujs6q5398jkaepd

- Bitcoin | Lightning: web3satsfinance@ln.satsails.com

- BTC-DEPIX-USDT | Liquid Network: lq1qq2gflwdl95jlexg6tmulcdgdlrv8jwc64ulnpp0jhs0xgx0v02vhyqqj6ag980al9gumlx3dk78q2q6yntqgzz9suuzjgf0nt

- BTC-USDT-USDC-EURC | (BSC/POL/BASE): 0x135a83c5a641a4265297853dd70b6f7565e5c8ed

Desenvolvido por THxWeb3Dev

Viva Soberano. Controle o Leviatã.